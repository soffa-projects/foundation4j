package io.soffa.foundation.pubsub.rabbitmq;

import lombok.Data;

@Data
public class AmqpClientConfig {

    private String exchange;
    private String routing;
    private String vhost = "/";
    private String addresses;
    private String username;
    private String password;
}
