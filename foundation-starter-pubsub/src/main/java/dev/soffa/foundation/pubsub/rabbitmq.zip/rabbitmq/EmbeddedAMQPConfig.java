package io.soffa.foundation.pubsub.rabbitmq;

import com.github.fridujo.rabbitmq.mock.MockConnectionFactory;
import io.soffa.foundation.commons.Logger;
import lombok.SneakyThrows;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
@ConditionalOnProperty(value = "app.amqp.enabled", havingValue = "true")
public class EmbeddedAMQPConfig {

    private static final Logger LOG = Logger.get(EmbeddedAMQPConfig.class);

    @SneakyThrows
    @Bean
    @Primary
    @ConditionalOnProperty(value = "spring.rabbitmq.addresses", havingValue = "embedded")
    public ConnectionFactory connectionFactory() {
        LOG.info("Embedded AMQP server enabled");
        RabbitMQConfig.embeddedMode = true;
        /*CachingConnectionFactory ccf = new CachingConnectionFactory(new MockConnectionFactory());
        try (Connection connexion = ccf.createConnection()) {
            try (Channel channel = connexion.createChannel(true)) {
                channel.exchangeDeclare("test", BuiltinExchangeType.TOPIC);
            }
        }*/
        return new CachingConnectionFactory(new MockConnectionFactory());
    }

}
